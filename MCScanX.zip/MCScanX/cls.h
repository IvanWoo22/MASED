#include <iostream>
#include <fstream>
#include "struct.h"


vector<more_feat> gene_more;
//geneSet allg;
