public class branch
{
   public int node1,node2;
   public branch(int x, int y)
   {
      this.node1=x;
      this.node2=y;
   }
}

