public class rt
{
  public int node;
  public double ypos;
  rt(int x,double y)
  {
    this.node=x;
    this.ypos=y;
  }
}

